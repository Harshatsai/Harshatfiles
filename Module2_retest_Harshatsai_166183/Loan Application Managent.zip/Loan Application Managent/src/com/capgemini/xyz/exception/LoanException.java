package com.capgemini.xyz.exception;

public class LoanException extends Exception {

}
